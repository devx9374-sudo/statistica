import sys, pathlib, unittest
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import aggiorna as A

# Dati di PROVA inventati: servono solo ai test e non fanno parte dell'archivio.
class T(unittest.TestCase):
    def test_parse_valido_e_scarti(self):
        r, s = A.parse("vincicasa", "2000-01-01;1;2;3;4;5\n02/01/2000;5;4;3;2;1\n2000-01-03;1;1;2;3;4\n2000-01-04;1;2;3;4;41\nxx")
        self.assertEqual((len(r), s), (2, 3)); self.assertEqual(r[1]["d"], "2000-01-02")
    def test_lotto_ruota_e_se_extra(self):
        self.assertEqual(len(A.parse("lotto", "2000-01-01;bari;1;2;3;4;5")[0]), 1)
        self.assertEqual(A.parse("lotto", "2000-01-01;1;2;3;4;5;6")[1], 1)
        r, _ = A.parse("superenalotto", "2000-01-01;1;2;3;4;5;6;7;8")
        self.assertEqual(r[0]["x"], [7, 8])
    def test_unisci_dedup_verifica_correzione(self):
        a, _ = A.parse("vincicasa", "2000-01-01;1;2;3;4;5")
        b, _ = A.parse("vincicasa", "2000-01-01;1;2;3;4;5\n2000-01-02;6;7;8;9;10")
        log = []
        arch, n, c = A.unisci([], [("uff", True, a), ("sec", False, b)], log)
        self.assertEqual((len(arch), n, c), (2, 2, 0)); self.assertEqual(arch[0]["ver"], "verificato")
        arch2, n2, _ = A.unisci(arch, [("uff", True, b)], log); self.assertEqual((len(arch2), n2), (2, 0))
        errata, _ = A.parse("vincicasa", "2000-01-01;1;2;3;4;6")
        arch3, _, c3 = A.unisci(arch2, [("uff", True, errata)], log)
        self.assertEqual(c3, 1); self.assertTrue(any(x["tipo"] == "correzione" for x in log))
        arch4, _, c4 = A.unisci(arch3, [("sec", False, a)], log)
        self.assertEqual(c4, 0); self.assertEqual(arch4[0]["n"], [1, 2, 3, 4, 6])
if __name__ == "__main__": unittest.main()
